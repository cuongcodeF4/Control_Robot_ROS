#!/usr/bin/env python
import math
import time
import smbus
import sys
import rospy
from std_msgs.msg import Float64


bus = smbus.SMBus(1)

ACCEL_XOUT_H = 0x3B
ACCEL_YOUT_H = 0x3D
ACCEL_ZOUT_H = 0x3F
GYRO_XOUT_H = 0x43
GYRO_YOUT_H = 0x45
GYRO_ZOUT_H = 0x47
MPU6050_ADDRESS = 0x68
PWR_MGMT_1 = 0x6B
SMPLRT_DIV = 0x19
CONFIG = 0x1A
GYRO_CONFIG = 0x1B
INT_ENABLE = 0x38

alpha = 0.98
dt = 0.005
limit_angle = 10
range_turn = 10
mpu = None


def read_raw_data(addr):
    high = bus.read_byte_data(mpu, addr)
    low = bus.read_byte_data(mpu, addr + 1)
    value = (high << 8) | low
    if value > 32768:
        value -= 65536
    return value


def init_mpu6050():
    global mpu
    # Initialize I2C communication with MPU6050
    mpu = bus.read_byte_data(MPU6050_ADDRESS, 0x75)
    if mpu != 0x68:
        print("connection fail.")
        exit(1)

    # Initialize power management
    bus.write_byte_data(mpu, PWR_MGMT_1, 0)
    # Set sample rate divider to 7 (1kHz / (1+1) = 500Hz)
    bus.write_byte_data(mpu, SMPLRT_DIV, 1)
    # Disable FSYNC, set 44.8Hz LPF
    bus.write_byte_data(mpu, CONFIG, 0)
    # Set gyro full scale range to ±2000°/sec
    bus.write_byte_data(mpu, GYRO_CONFIG, 24)
    # Enable interrupt on data ready
    bus.write_byte_data(mpu, INT_ENABLE, 1)


def get_rotation(roll, pitch, yaw):
    # Read raw accelerometer and gyro data
    accel_x = read_raw_data(ACCEL_XOUT_H)
    accel_y = read_raw_data(ACCEL_YOUT_H)
    accel_z = read_raw_data(ACCEL_ZOUT_H)
    gyro_x = read_raw_data(GYRO_XOUT_H)
    gyro_y = read_raw_data(GYRO_YOUT_H)
    gyro_z = read_raw_data(GYRO_ZOUT_H)

    # Convert raw values to degrees per second
    gyro_scale = 16.4  # LSB Sensitivity
    accel_scale = 16384.0
    gyro_x_scaled = gyro_x / gyro_scale
    gyro_y_scaled = gyro_y / gyro_scale
    gyro_z_scaled = gyro_z / gyro_scale

    # Calculate rotation angle using complementary filter
   
    roll[0] = alpha * (roll[0] + gyro_x_scaled * dt) + (1 - alpha) * math.atan2(accel_y, accel_z) * 180 / math.pi
    pitch[0] = alpha * (pitch[0] + gyro_y_scaled * dt) + (1 - alpha) * math.atan2(-accel_x, math.sqrt(accel_y * accel_y + accel_z * accel_z)) * 180 / math.pi
    yaw[0] = yaw[0] + gyro_z_scaled * dt
    
    return roll, pitch, yaw


def Vel_robot(roll, pitch):
    Vel_Rwheel = 0
    Vel_Lwheel = 0
    set_vel = 12      #rad/s
    div = 1/2.5
    offset_angle = 90- limit_angle
    accel_factor = (4 - (abs(roll)-limit_angle)*4/offset_angle)   # acceleration factor from 4 - 0 , as the angle increases, the coefficient decreases
    Vel = 0
    if (roll) >= 90:
        roll= 90
    elif roll <= -90:
        roll = -90
        
    if (-limit_angle<=roll <=limit_angle) and (-range_turn<=pitch <=range_turn):
        Vel_Rwheel = 0
        Vel_Lwheel = 0
    elif (roll >limit_angle ) and (-range_turn<=pitch <=range_turn ):
        Vel = (roll-limit_angle) * (set_vel/offset_angle) * accel_factor   # Set max velocity = 12 rad/s and range angle from : 0 - 70 deg 
                                                                     # current velocity =  current angle * 12/80
        Vel_Rwheel = -Vel
        Vel_Lwheel = Vel                                              
    elif (roll <-5 ) and (-range_turn<=pitch <=range_turn ):
        Vel = (abs(roll)-limit_angle) * (set_vel/offset_angle) * accel_factor   
        Vel_Rwheel = Vel
        Vel_Lwheel =  -Vel
    elif (roll >limit_angle ) and (pitch >range_turn ):
        Vel = (roll-limit_angle) * (set_vel/offset_angle) * accel_factor   
        turnLR_factor = (abs(pitch) -range_turn ) * Vel/offset_angle                                                   
        Vel_Rwheel = -Vel
        Vel_Lwheel = (Vel -turnLR_factor/div)
    elif (roll >limit_angle ) and (pitch <-range_turn ):
        Vel = (abs(roll)-limit_angle) * (set_vel/offset_angle) * accel_factor   
                                                                
        turnLR_factor = (abs(pitch) -range_turn ) * Vel/offset_angle
        Vel_Rwheel = -(Vel -turnLR_factor/div)
        Vel_Lwheel = Vel 
    elif (roll <-limit_angle ) and (pitch >range_turn ):
        Vel = (abs(roll)-limit_angle) * (set_vel/offset_angle) * accel_factor   
        turnLR_factor = (abs(pitch) -range_turn ) * Vel/offset_angle
        Vel_Rwheel = Vel
        Vel_Lwheel = -(Vel -turnLR_factor/div)
    elif (roll <-limit_angle ) and (pitch <-range_turn ):
        Vel = (abs(roll)-limit_angle) * (set_vel/offset_angle) * accel_factor   
        turnLR_factor = (abs(pitch) -range_turn ) * Vel/offset_angle
        Vel_Rwheel = (Vel -turnLR_factor/div)
        Vel_Lwheel = -Vel 

    return Vel_Rwheel,Vel_Lwheel

# Ham publish
def talker():
    pub1 = rospy.Publisher('/my_diffbot/joint1_velocity_controller/command', Float64, queue_size=3)
    pub2 = rospy.Publisher('/my_diffbot/joint2_velocity_controller/command', Float64, queue_size=3)
    rospy.init_node('control_velocity', anonymous=True)
    rate = rospy.Rate(50000) # 50000hz
    roll = [0]
    pitch = [0]
    yaw = [0]
    while not rospy.is_shutdown():
        init_mpu6050()
        get_rotation(roll, pitch, yaw)
        Vel_Rwheel,Vel_Lwheel= Vel_robot(roll[0], pitch[0])
        sys.stdout.write(f"\rRoll: {roll[0]:.2f}, Pitch: {pitch[0]:.2f}, Vel_R: {Vel_Rwheel:.2f}, Vel_L: {Vel_Lwheel:.2f}")
        sys.stdout.flush()
        rospy.loginfo(Vel_Rwheel)
        rospy.loginfo(Vel_Lwheel)
        pub1.publish(Vel_Rwheel)
        pub2.publish(Vel_Lwheel)
        rate.sleep()
if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
