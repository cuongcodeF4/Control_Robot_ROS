#!/usr/bin/env python
# license removed for brevity
import rospy
from std_msgs.msg import Float64
i = 0
def talker():
    pub1 = rospy.Publisher('/my_diffbot/joint1_position_controller/command', Float64, queue_size=10)
    pub2 = rospy.Publisher('/my_diffbot/joint2_position_controller/command', Float64, queue_size=10)
    rospy.init_node('rbcontrol_pub', anonymous=True)
    rate = rospy.Rate(50) # 10hz
    
    
    while not rospy.is_shutdown():
    	
        global i
        i += 0.017
        data1 = i
        data2 = -data1
        
        publishData1 = data1
        publishData2 = data2
        
        rospy.loginfo(publishData1)
        rospy.loginfo(publishData2)
        
        pub1.publish(publishData1)
        pub2.publish(publishData2)
        rate.sleep()
        
        if (i >= 6.12):
            i = 0
        

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass