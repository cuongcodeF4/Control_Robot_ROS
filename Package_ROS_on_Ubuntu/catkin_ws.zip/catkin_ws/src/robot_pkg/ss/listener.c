#include <stdio.h>
#include <stdlib.h>
#include "ros/ros.h"
#include "std_msgs/String.h"

void chatterCallback(const std_msgs__String msg)
{
  printf("I heard: [%s]\n", msg->data.data);
}

int main(int argc, char** argv)
{
  ros_init(&argc, &argv, "listener");
  ros_NodeHandle n;
  ros_Subscriber sub = n.subscribe("chatter", 1000, chatterCallback);
  ros_spin();
  return 0;
}